import spojsubmit

if __name__ == "__main__":
    __name__ = "spojbot"
    spojsubmit.main()
